/** Automatically generated file. DO NOT MODIFY */
package cn.xiaoshangfan.liangshuang;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}