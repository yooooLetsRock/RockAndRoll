package cn.xiaoshangfan.liangshuang;

//import cn.bmob.v3.BmobUser;
import cn.bmob.v3.listener.ResetPasswordListener;
import cn.bmob.v3.listener.SaveListener;
import cn.xiaoshangfan.liangshuang.entity.User;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class UserLoginActivity extends Activity implements OnClickListener{

	EditText password,email;
	Button login,register;
	TextView passwordback;
	User user = new User();
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.user_login);
		// ��ʼ��View
		initView();
		initListener();
	}
	
	private void initView() {
		//name = (EditText) findViewById(R.id.editText_name);
		password = (EditText) findViewById(R.id.editText_Password);
		email = (EditText) findViewById(R.id.editText_Email);
		login = (Button) findViewById(R.id.button_Login);
		register = (Button) findViewById(R.id.button_register);
		passwordback = (TextView) findViewById(R.id.textView_getUsername);
	}

	private void initListener() {
		login.setOnClickListener(this);
		register.setOnClickListener(this);
		passwordback.setOnClickListener(this);
	}
	
	@Override
	public void onClick(View v) {
		if(v == login){
			LoginUser();
		}
        if(v == register){
        	Intent intentlog = new Intent(UserLoginActivity.this,UserRegisterActivity.class);
	        startActivity(intentlog);
		}
        if(v == passwordback){
        	final String passwback = email.getText().toString();
        	User.resetPassword(this, passwback, new ResetPasswordListener() {
        	    public void onSuccess() {
        	        // TODO Auto-generated method stub
        	        toast("������������ɹ����뵽" + passwback + "��������������ò���");
        	    }
        	    public void onFailure(int code, String e) {
        	        // TODO Auto-generated method stub
        	        toast("��������ʧ��:" + e);
        	    }
        	});
		}
	}
	
	public void LoginUser(){
		
		final String emailInfo = email.getText().toString();
        String passwordInfo = password.getText().toString();
		user.setUsername(emailInfo);
		user.setPassword(passwordInfo);
		user.setEmail(emailInfo);
		user.login(this, new SaveListener() {
		    @Override
		    public void onSuccess() {
		        // TODO Auto-generated method stub
		        toast("��¼�ɹ�");
		        
		        //Intent data=new Intent();  
		        //data.putExtra("name", emailInfo); 
		        //setResult(1, data);  
		        //finish();  

		        Intent intent = new Intent(UserLoginActivity.this,MainActivity.class);
		        startActivity(intent);
		    }
		    @Override
		    public void onFailure(int code, String msg) {
		        // TODO Auto-generated method stub
		        toast("��¼ʧ��:"+msg);
		    }
		});
	}
	
	
	Toast mToast;
	protected void toast(String string) {
		// TODO Auto-generated method stub
		if (!TextUtils.isEmpty(string)) {
			if (mToast == null) {
				mToast = Toast.makeText(getApplicationContext(), string,
						Toast.LENGTH_SHORT);
			} else {
				mToast.setText(string);
			}
			mToast.show();
		}
	}

	
}
