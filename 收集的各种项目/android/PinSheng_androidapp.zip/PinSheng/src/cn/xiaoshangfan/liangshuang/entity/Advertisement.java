package cn.xiaoshangfan.liangshuang.entity;

import java.io.Serializable;

import cn.bmob.v3.BmobObject;
import cn.bmob.v3.datatype.BmobFile;

public class Advertisement extends BmobObject implements Serializable {

	private static final long serialVersionUID = -9087923104331607547L;
	/**
	 * 
	 */

	private String ads_text;
	private int num_of_people;
	private BmobFile ads_img;
	private int ads_fraction_get;
	private int ads_fraction_total;
	private int imageWidth;
	private int imageHeight;
	private String img_inside_text;

	public String get_ads_text() {
		return this.ads_text;
	}

	public void set_ads_text(String text) {
		this.ads_text = text;
	}

	public int get_num_of_people() {
		return this.num_of_people;
	}

	public void set_num_of_people(int number) {
		this.num_of_people = number;
	}

	public BmobFile get_ads_img() {
		return this.ads_img;
	}

	public void set_ads_img(BmobFile img) {
		this.ads_img = img;
	}

	public int get_ads_fraction_get() {
		return this.ads_fraction_get;
	}

	public void set_ads_fraction_get(int number) {
		this.ads_fraction_get = number;
	}

	public int get_ads_fraction_total() {
		return this.ads_fraction_total;
	}

	public void set_ads_fraction_total(int number) {
		this.ads_fraction_total = number;
	}

	public int getImageWidth() {
		return this.imageWidth;
	}

	public void setImageWidth(int number) {
		this.imageWidth = number;
	}

	public int getImageHeight() {
		return this.imageHeight;
	}

	public void setImageHeight(int number) {
		this.imageHeight = number;
	}

	public void setImg_inside_text(String t) {
		this.img_inside_text = t;
	}

	public String getImg_inside_text() {
		return this.img_inside_text;
	}
}
