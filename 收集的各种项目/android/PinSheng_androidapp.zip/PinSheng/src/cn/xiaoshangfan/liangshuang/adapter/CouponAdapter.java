package cn.xiaoshangfan.liangshuang.adapter;

import java.util.List;

import com.nostra13.universalimageloader.core.ImageLoader;

import cn.bmob.v3.BmobQuery;
import cn.bmob.v3.BmobUser;
import cn.bmob.v3.listener.FindListener;
import cn.bmob.v3.listener.SaveListener;
import cn.bmob.v3.listener.UpdateListener;
import cn.xiaoshangfan.liangshuang.CircleImageView;
import cn.xiaoshangfan.liangshuang.R;
import cn.xiaoshangfan.liangshuang.entity.Coupon;
import cn.xiaoshangfan.liangshuang.entity.TradeCoupon;
import cn.xiaoshangfan.liangshuang.entity.User;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class CouponAdapter extends BaseAdapter {

	private List<Coupon> couponList;
	private Context mContext;
	private User user;
	boolean loged = false;

	public CouponAdapter(Context context, List<Coupon> list) {
		mContext = context;
		couponList = list;
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return couponList != null ? couponList.size() : 0;
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}

	@SuppressLint({ "ViewHolder", "InflateParams" })
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		final Coupon coupon = couponList.get(position);

		user = BmobUser.getCurrentUser(mContext, User.class);
		if (user != null) {
			loged = true;
		}

		LayoutInflater inflater = LayoutInflater.from(mContext);
		convertView = inflater.inflate(R.layout.coupon_item, null);

		CircleImageView img = (CircleImageView) convertView
				.findViewById(R.id.imageView_couponImg);

		TextView validDaysTextView = (TextView) convertView
				.findViewById(R.id.textView_validDays);

		TextView couponDiscTextView = (TextView) convertView
				.findViewById(R.id.textView_couponDisc);

		TextView couponValue = (TextView) convertView
				.findViewById(R.id.textView_couponValue);

		// coupon.getCouponImg().loadImage(mContext, img);
		// 测试阶段 应该为取值后判断天数
		ImageLoader.getInstance().displayImage(
				coupon.getCouponImg().getFileUrl(), img);

		validDaysTextView.setText(coupon.getCreatedAt());

		couponDiscTextView.setText(coupon.getCouponDiscribe());

		couponValue.setText(String.valueOf(coupon.getValue()));

		LinearLayout linelayout = (LinearLayout) convertView
				.findViewById(R.id.linearLayout_coupon_item);
		linelayout.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub

				final TradeCoupon tradecoupon = new TradeCoupon();

				tradecoupon.setUser(user);
				tradecoupon.setCoupon(coupon);

				BmobQuery<TradeCoupon> query = new BmobQuery<TradeCoupon>();
				// 这里写查询的条件
				query.addWhereEqualTo("user", user);
				query.addWhereEqualTo("coupon", coupon);
				query.findObjects(mContext, new FindListener<TradeCoupon>() {
					@Override
					public void onSuccess(List<TradeCoupon> tc) {
						// TODO Auto-generated method stub
						if (tc.size() == 0) {
							tradecoupon.setState(0);
							Log.d(" 1state",
									String.valueOf(tradecoupon.getState()));
						} else {
							tradecoupon.setCoupon(tc.get(0).getCoupon());
							tradecoupon.setUser(tc.get(0).getUser());
							tradecoupon.setState(tc.get(0).getState());
							Log.d("2 state",
									String.valueOf(tradecoupon.getState()));
						}

					}

					@Override
					public void onError(int code, String msg) {
						// TODO Auto-generated method stub
						Toast.makeText(mContext, "网络问题，无法获取数据",
								Toast.LENGTH_SHORT).show();
					}
				});

				Dialog alertDialog = new AlertDialog.Builder(mContext)
						.setTitle("每个优惠券只能兑换一次")
						.setPositiveButton("兑换",
								new DialogInterface.OnClickListener() {

									@Override
									public void onClick(DialogInterface dialog,
											int which) {
										// TODO Auto-generated method stub
										if (loged) {
											if (tradecoupon.getState() == 0) {
												// 判断用户积分是否足够

												int fraction = user
														.getUserFraction()
														- coupon.getValue();

												Log.d("couponadapter",
														String.valueOf(user
																.getUserFraction()));

												if (fraction < 0) {
													Toast.makeText(mContext,
															"积分不够请去发现赚积分",
															Toast.LENGTH_SHORT)
															.show();
												} else {

													user.setUserFraction(fraction);
													user.update(
															mContext,
															new UpdateListener() {

																@Override
																public void onSuccess() {
																	// TODO
																	// Auto-generated
																	// method
																	// stub

																}

																@Override
																public void onFailure(
																		int arg0,
																		String arg1) {
																	// TODO
																	// Auto-generated
																	// method
																	// stub
																	Toast.makeText(
																			mContext,
																			"更新用户信息失败",
																			Toast.LENGTH_LONG)
																			.show();

																}
															});

													// save to bmob
													tradecoupon.setState(2);
													tradecoupon.save(mContext,
															new SaveListener() {

																@Override
																public void onSuccess() {
																	// TODO
																	// Auto-generated
																	// method
																	// stub
																	Toast.makeText(
																			mContext,
																			"兑换成功,可以到我的查看",
																			Toast.LENGTH_SHORT)
																			.show();

																}

																@Override
																public void onFailure(
																		int arg0,
																		String arg1) {
																	// TODO
																	// Auto-generated
																	// method
																	// stub

																}
															});

												}

											} else if (tradecoupon.getState() == 1) {
												tradecoupon.setState(2);

												tradecoupon.update(mContext,
														tradecoupon
																.getObjectId(),
														new UpdateListener() {

															@Override
															public void onSuccess() {
																// TODO
																// Auto-generated
																// method stub
																Log.d("suc",
																		"suc");
															}

															@Override
															public void onFailure(
																	int arg0,
																	String arg1) {
																// TODO
																// Auto-generated
																// method stub

															}
														});

											} else {
												Toast.makeText(mContext,
														"您已经获得过该优惠券了哦",
														Toast.LENGTH_SHORT)
														.show();
											}
										} else {
											Toast.makeText(mContext, "您还没有登陆",
													Toast.LENGTH_SHORT).show();
										}
									}
								})
						.setNegativeButton("收藏",
								new DialogInterface.OnClickListener() {

									@Override
									public void onClick(DialogInterface dialog,
											int which) {
										// TODO Auto-generated method stub
										if (loged) {
											if (tradecoupon.getState() == 1) {
												Toast.makeText(mContext,
														"您已经收藏过该优惠券了哦",
														Toast.LENGTH_SHORT)
														.show();
											} else if (tradecoupon.getState() == 2) {
												Toast.makeText(mContext,
														"您已经获得了该优惠券了哦",
														Toast.LENGTH_SHORT)
														.show();
											} else {
												tradecoupon.setState(1);
												tradecoupon.save(mContext,
														new SaveListener() {

															@Override
															public void onSuccess() {
																// TODO
																// Auto-generated
																// method stub
																Toast.makeText(
																		mContext,
																		"收藏成功",
																		Toast.LENGTH_SHORT)
																		.show();
															}

															@Override
															public void onFailure(
																	int arg0,
																	String arg1) {
																// TODO
																// Auto-generated
																// method stub
																Toast.makeText(
																		mContext,
																		"网络错误",
																		Toast.LENGTH_SHORT)
																		.show();
															}
														});
											}
										} else {
											Toast.makeText(mContext, "您还没有登陆",
													Toast.LENGTH_SHORT).show();
										}
									}
								}).create();
				alertDialog.show();
			}
		});

		return convertView;
	}
}
