package cn.xiaoshangfan.liangshuang.adapter;

import java.util.LinkedList;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.TextView;
import cn.xiaoshangfan.liangshuang.AdDetail;
import cn.xiaoshangfan.liangshuang.R;
import cn.xiaoshangfan.liangshuang.entity.Advertisement;

import com.nostra13.universalimageloader.core.ImageLoader;

public class AdsAdapter extends BaseAdapter {

	private LinkedList<Advertisement> mAdsList;
	private Context mContext;
	private int screen_width;

	@SuppressWarnings("deprecation")
	public AdsAdapter(Context context, LinkedList<Advertisement> adsList) {
		mContext = context;
		mAdsList = adsList;

		WindowManager wm = (WindowManager) context
				.getSystemService(Context.WINDOW_SERVICE);

		screen_width = wm.getDefaultDisplay().getWidth();
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return mAdsList != null ? mAdsList.size() : 0;
	}

	@Override
	public Object getItem(int position) {
		return null;
	}

	@Override
	public long getItemId(int position) {
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		final Holder holder;
		final Advertisement ad = mAdsList.get(position);
		// 得到View
		if (convertView == null) {
			holder = new Holder();
			LayoutInflater inflater = LayoutInflater.from(mContext);
			convertView = inflater.inflate(R.layout.ads_item, null);
			holder.adImageView = (ImageView) convertView
					.findViewById(R.id.imageView_item_img);

			holder.adTextView = (TextView) convertView
					.findViewById(R.id.textView_item_text);

			convertView.setTag(holder);
		} else {
			holder = (Holder) convertView.getTag();
		}

		String textString = ad.get_ads_text();
		holder.adTextView.setText(textString);

		String imgUrl = ad.get_ads_img().getFileUrl();

		// 这儿初先初始化出来image所占的位置的大小，先把瀑布流固定住，这样瀑布流就不会因为图片加载出来后大小变化了
		LayoutParams lp = (LayoutParams) holder.adImageView.getLayoutParams();
		// 多屏幕适配
		int imageWid = ad.getImageWidth();
		int imageHei = ad.getImageHeight();

		long width = (screen_width - 4 * 4) / 2;
		long height = (long) ((width * imageHei) / imageWid - (width * 0.01));

		lp.width = (int) width;
		lp.height = (int) height;

		holder.adImageView.setLayoutParams(lp);

		ImageLoader.getInstance().displayImage(imgUrl, holder.adImageView);
		holder.adImageView.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View view) {
				// TODO Auto-generated method stub
				Log.i("TAG", "image click");

				Intent intent = new Intent(mContext, AdDetail.class);
				Bundle mBundle = new Bundle();
				mBundle.putSerializable("ad", ad);
				intent.putExtras(mBundle);
				mContext.startActivity(intent);

			}
		});

		return convertView;
	}

}

class Holder {
	public ImageView adImageView;
	public TextView adTextView;
}
