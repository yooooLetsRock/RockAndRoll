package cn.xiaoshangfan.liangshuang;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import cn.bmob.v3.Bmob;
import cn.bmob.v3.BmobUser;
import cn.xiaoshangfan.liangshuang.entity.User;

public class MainActivity extends FragmentActivity {

	private Fragment[] fragments;
	User user = new User();
	Boolean IsRecord = false;

	RelativeLayout adsLayout;
	RelativeLayout couponLayout;
	RelativeLayout meLayout;

	TextView adstTextView;
	TextView coupontTextView;
	TextView metTextView;

	ImageView adsImageView;
	ImageView couponImageView;
	ImageView meImageView;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// requestWindowFeature(Window.FEATURE_NO_TITLE);
		// 初始化 Bmob SDK
		Bmob.initialize(this, "d9e97f48bdbd826859d9eb6990953e09");
		user = BmobUser.getCurrentUser(this, User.class);

		if (user != null) {
			IsRecord = true;

		} else {
			IsRecord = false;
			Log.d("user", "false");
		}
		setContentView(R.layout.activity_main);
		setTitle("   积积");

		fragments = new Fragment[3];
		fragments[0] = getSupportFragmentManager().findFragmentById(
				R.id.farment_ads);
		fragments[1] = getSupportFragmentManager().findFragmentById(
				R.id.farment_coupon);
		fragments[2] = getSupportFragmentManager().findFragmentById(
				R.id.farment_personalcenter);
		getSupportFragmentManager().beginTransaction().hide(fragments[1])
				.hide(fragments[2]).show(fragments[0]).commit();

		adsLayout = (RelativeLayout) findViewById(R.id.ralativeLayout_ads);
		couponLayout = (RelativeLayout) findViewById(R.id.ralativeLayout_coupon);
		meLayout = (RelativeLayout) findViewById(R.id.ralativeLayout_me);

		adstTextView = (TextView) findViewById(R.id.textview_ads);
		coupontTextView = (TextView) findViewById(R.id.textview_coupon);
		metTextView = (TextView) findViewById(R.id.textview_me);

		adsImageView = (ImageView) findViewById(R.id.imageView_ads);
		couponImageView = (ImageView) findViewById(R.id.imageView_coupon);
		meImageView = (ImageView) findViewById(R.id.imageView_me);

	}

	public void adsClick(View view) {
		getSupportFragmentManager().beginTransaction().hide(fragments[1])
				.hide(fragments[2]).show(fragments[0]).commit();
		adstTextView.setTextColor(0xFFcc2637);
		coupontTextView.setTextColor(0xFF5b5b5b);
		metTextView.setTextColor(0xFF5b5b5b);

		adsImageView.setImageResource(R.drawable.discover_select);
		couponImageView.setImageResource(R.drawable.coupon_nor);
		meImageView.setImageResource(R.drawable.me_nor);

	}

	public void couponClick(View view) {
		getSupportFragmentManager().beginTransaction().hide(fragments[0])
				.hide(fragments[2]).show(fragments[1]).commit();
		adstTextView.setTextColor(0xFF5b5b5b);
		coupontTextView.setTextColor(0xFFcc2637);
		metTextView.setTextColor(0xFF5b5b5b);

		adsImageView.setImageResource(R.drawable.discover_nor);
		couponImageView.setImageResource(R.drawable.coupon_select);
		meImageView.setImageResource(R.drawable.me_nor);
	}

	public void meClick(View view) {
		if (!IsRecord) {
			Intent intent = new Intent(MainActivity.this,
					UserLoginActivity.class);
			startActivity(intent);
		} else {
			getSupportFragmentManager().beginTransaction().hide(fragments[0])
					.hide(fragments[1]).show(fragments[2]).commit();
			adstTextView.setTextColor(0xFF5b5b5b);
			coupontTextView.setTextColor(0xFF5b5b5b);
			metTextView.setTextColor(0xFFcc2637);

			adsImageView.setImageResource(R.drawable.discover_nor);
			couponImageView.setImageResource(R.drawable.coupon_nor);
			meImageView.setImageResource(R.drawable.me_select);
			fragments[2].onResume();
		}

	}

}
