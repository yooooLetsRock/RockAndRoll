package cn.xiaoshangfan.liangshuang.adapter;

import java.util.LinkedList;
import java.util.List;

import com.nostra13.universalimageloader.core.ImageLoader;

import cn.xiaoshangfan.liangshuang.CircleImageView;
import cn.xiaoshangfan.liangshuang.R;
import cn.xiaoshangfan.liangshuang.entity.Coupon;
import cn.xiaoshangfan.liangshuang.entity.TradeCoupon;
import cn.xiaoshangfan.liangshuang.entity.User;
import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class CouponFavAdapter extends BaseAdapter {

	private List<TradeCoupon> couponList;
	private Context mContext;
	private User user;

	public CouponFavAdapter(Context context, LinkedList<TradeCoupon> couponList2) {
		mContext = context;
		couponList = couponList2;
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return couponList != null ? couponList.size() : 0;
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}

	@SuppressLint({ "ViewHolder", "InflateParams" })
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub

		TradeCoupon tradecoupon = couponList.get(position);

		LayoutInflater inflater = LayoutInflater.from(mContext);
		convertView = inflater.inflate(R.layout.coupon_fra_item, null);

		CircleImageView img = (CircleImageView) convertView
				.findViewById(R.id.imageView_couponFraImg);

		TextView couponFraText = (TextView) convertView
				.findViewById(R.id.textView_couponfratext);

		ImageLoader.getInstance().displayImage(
				tradecoupon.getCoupon().getCouponImg().getFileUrl(), img);

		couponFraText.setText(tradecoupon.getCoupon().getCouponDiscribe());

		return convertView;
	}

}
