package cn.xiaoshangfan.liangshuang.entity;

import cn.bmob.v3.BmobObject;
import cn.bmob.v3.datatype.BmobFile;

public class Coupon extends BmobObject {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7010444992472081152L;

	private int value;
	private String shopName;
	private String couponDiscribe;
	private String shopAdress;
	private int numOfTotalGet;
	private BmobFile couponImg;

	public int getValue() {
		return this.value;
	}

	public void setValue(int value) {
		this.value = value;
	}

	public String getShopName() {
		return this.shopName;
	}

	public void setShopName(String shopname) {
		this.shopName = shopname;
	}

	public String getCouponDiscribe() {
		return this.couponDiscribe;
	}

	public void setCouponDiscribe(String discribe) {
		this.couponDiscribe = discribe;
	}

	public String getShopAdress() {
		return this.shopAdress;
	}

	public void setShopAdress(String adress) {
		this.shopAdress = adress;
	}

	public int getTotalGet() {
		return this.numOfTotalGet;
	}

	public void setTotalGet(int num) {
		this.numOfTotalGet = num;
	}

	public BmobFile getCouponImg() {
		return this.couponImg;
	}

	public void setCouponImg(BmobFile img) {
		this.couponImg = img;
	}

}
