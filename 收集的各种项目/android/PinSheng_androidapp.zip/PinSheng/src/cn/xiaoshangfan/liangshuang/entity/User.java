package cn.xiaoshangfan.liangshuang.entity;

import cn.bmob.v3.BmobUser;

public class User extends BmobUser {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8071397876334664085L;

	private int userFraction;

	public void setUserFraction(int num) {
		this.userFraction = num;
	}

	public int getUserFraction() {
		return userFraction;
	}

}
