package cn.xiaoshangfan.liangshuang.entity;

import cn.bmob.v3.BmobObject;

public class TradeAd extends BmobObject {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5859127937597710437L;

	private User user;
	private Advertisement ad;

	// state状态数字代表分别为 0（已经获取） 1（尚未获取）
	private int state;

	public void setUser(User u) {
		this.user = u;
	}

	public User getUser() {
		return this.user;
	}

	public void setAd(Advertisement d) {
		this.ad = d;
	}

	public Advertisement getAd() {
		return this.ad;
	}

	public void setState(int num) {
		this.state = num;
	}

	public int getState() {
		return this.state;
	}
}
