package cn.xiaoshangfan.liangshuang.fragments;

import java.util.LinkedList;
import java.util.List;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TabHost;
import android.widget.TextView;
import android.widget.Toast;
import cn.bmob.v3.BmobQuery;
import cn.bmob.v3.BmobUser;
import cn.bmob.v3.listener.FindListener;
import cn.xiaoshangfan.liangshuang.R;
import cn.xiaoshangfan.liangshuang.adapter.CouponFavAdapter;
import cn.xiaoshangfan.liangshuang.entity.TradeCoupon;
import cn.xiaoshangfan.liangshuang.entity.User;

public class PersonnalCenterFragment extends Fragment {
	User user = new User();
	private TabHost tabhost;
	ListView listview_aready_get;
	ListView listview_frav;
	TextView userFraction;
	private CouponFavAdapter mCouponFraAdapter;
	public LinkedList<TradeCoupon> tradecouponList = new LinkedList<TradeCoupon>();

	private CouponFavAdapter mCouponFraAdapter2;
	public LinkedList<TradeCoupon> tradecouponList2 = new LinkedList<TradeCoupon>();

	private FragmentActivity activity;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.fragment_personnalcenter,
				container, false);

		activity = getActivity();

		tabhost = (TabHost) view.findViewById(android.R.id.tabhost);
		tabhost.setup();

		tabhost.addTab(tabhost.newTabSpec("tab1").setIndicator("已得优惠券")
				.setContent(R.id.tab1));
		tabhost.addTab(tabhost.newTabSpec("tab2").setIndicator("收藏")
				.setContent(R.id.tab2));

		mCouponFraAdapter = new CouponFavAdapter(activity, tradecouponList);
		mCouponFraAdapter2 = new CouponFavAdapter(activity, tradecouponList2);

		listview_aready_get = (ListView) view
				.findViewById(R.id.listView_aready_get);
		listview_frav = (ListView) view.findViewById(R.id.listView_fravo);

		userFraction = (TextView) view.findViewById(R.id.textView_cur_fraction);

		userFraction.setText(String.valueOf(user.getUserFraction()));

		return view;
	}

	@Override
	public void onResume() {
		// TODO Auto-generated method stub
		user = BmobUser.getCurrentUser(getActivity(), User.class);
		if (user != null) {
			userFraction.setText(String.valueOf(user.getUserFraction()));
		}
		super.onResume();
		Log.d("onresume", "true");

		BmobQuery<TradeCoupon> query = new BmobQuery<TradeCoupon>();
		query.addWhereEqualTo("user", user);
		query.addWhereEqualTo("state", 2);
		query.include("coupon");
		query.findObjects(activity, new FindListener<TradeCoupon>() {
			@Override
			public void onSuccess(List<TradeCoupon> coupons) {
				// TODO Auto-generated method stub
				if (coupons.size() == 0) {
					Toast.makeText(activity, "获得已得优惠券失败", Toast.LENGTH_LONG)
							.show();
				} else {
					tradecouponList.clear();
					tradecouponList.addAll(coupons);
					listview_aready_get.setAdapter(mCouponFraAdapter);
				}
			}

			@Override
			public void onError(int arg0, String arg1) {
				// TODO Auto-generated method stub
				Toast.makeText(getActivity(), arg1, Toast.LENGTH_LONG).show();
			}

		});

		BmobQuery<TradeCoupon> query2 = new BmobQuery<TradeCoupon>();
		query2.addWhereEqualTo("user", user);
		query2.addWhereEqualTo("state", 1);
		query2.include("coupon");
		query2.findObjects(activity, new FindListener<TradeCoupon>() {
			@Override
			public void onSuccess(List<TradeCoupon> coupons2) {
				// TODO Auto-generated method stub

				Log.d("shoucang", String.valueOf(coupons2.size()));

				if (coupons2.size() == 0) {
					Toast.makeText(activity, "获得收藏失败", Toast.LENGTH_LONG)
							.show();
				} else {
					tradecouponList2.clear();
					tradecouponList2.addAll(coupons2);
					listview_frav.setAdapter(mCouponFraAdapter2);
				}
			}

			@Override
			public void onError(int arg0, String arg1) {
				// TODO Auto-generated method stub
				Toast.makeText(getActivity(), arg1, Toast.LENGTH_LONG).show();
			}

		});
	}

}