package cn.xiaoshangfan.liangshuang.entity;

import cn.bmob.v3.BmobObject;

public class TradeCoupon extends BmobObject {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3199769005210796806L;

	private User user;
	private Coupon coupon;
	private int state; // 0表示尚未有记录，1表示收藏，2表示获得

	public TradeCoupon() {
		// TODO Auto-generated constructor stub
		state = 0;
	}

	public void setUser(User u) {
		this.user = u;
	}

	public User getUser() {
		return this.user;
	}

	public void setCoupon(Coupon c) {
		this.coupon = c;
	}

	public Coupon getCoupon() {
		return this.coupon;
	}

	public void setState(int num) {
		this.state = num;
	}

	public int getState() {
		return this.state;
	}

}
