package cn.xiaoshangfan.liangshuang;

import android.app.Activity;

public class CouponDetail extends Activity {
	
	

}
