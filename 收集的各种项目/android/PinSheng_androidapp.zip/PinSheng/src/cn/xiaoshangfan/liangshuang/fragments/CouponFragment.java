package cn.xiaoshangfan.liangshuang.fragments;

import java.util.LinkedList;
import java.util.List;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.Toast;
import cn.bmob.v3.Bmob;
import cn.bmob.v3.BmobQuery;
import cn.bmob.v3.BmobUser;
import cn.bmob.v3.listener.FindListener;
import cn.xiaoshangfan.liangshuang.R;
import cn.xiaoshangfan.liangshuang.adapter.CouponAdapter;
import cn.xiaoshangfan.liangshuang.entity.Coupon;
import cn.xiaoshangfan.liangshuang.entity.User;

public class CouponFragment extends Fragment {

	private FragmentActivity activity;
	private ListView couponListView = null;
	private CouponAdapter mCouponAdapter;
	public LinkedList<Coupon> couponList = new LinkedList<Coupon>();

	User user = new User();
	boolean areadyGet = false;
	boolean loged = false;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {

		activity = getActivity();
		View view = inflater
				.inflate(R.layout.fragment_coupon, container, false);
		couponListView = (ListView) view.findViewById(R.id.listView_coupon);
		
		user = BmobUser.getCurrentUser(activity, User.class);
		mCouponAdapter = new CouponAdapter(activity, couponList);
		getData();
		return view;
	}

	private void getData() {

		BmobQuery<Coupon> query = new BmobQuery<Coupon>();
		query.setLimit(10);// 设置分页，取10个数据
		query.findObjects(activity, new FindListener<Coupon>() {
			@Override
			public void onSuccess(List<Coupon> coupons) {
				// TODO Auto-generated method stub
				if (coupons.size() == 0) {
					Toast.makeText(activity, "没有数据", Toast.LENGTH_LONG).show();
				} else {
					couponList.addAll(coupons);
					couponListView.setAdapter(mCouponAdapter);
				}
			}

			@Override
			public void onError(int arg0, String arg1) {
				// TODO Auto-generated method stub
				Toast.makeText(getActivity(), arg1, Toast.LENGTH_LONG).show();
			}

		});
	}

	@Override
	public void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		user = BmobUser.getCurrentUser(activity, User.class);
		if (user != null) {
			loged = true;
		}
	}

}
