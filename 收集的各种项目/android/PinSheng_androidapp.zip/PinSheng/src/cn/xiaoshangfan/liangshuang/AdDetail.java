package cn.xiaoshangfan.liangshuang;

import java.util.List;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;
import cn.bmob.v3.Bmob;
import cn.bmob.v3.BmobQuery;
import cn.bmob.v3.BmobUser;
import cn.bmob.v3.listener.FindListener;
import cn.bmob.v3.listener.SaveListener;
import cn.bmob.v3.listener.UpdateListener;
import cn.xiaoshangfan.liangshuang.entity.Advertisement;
import cn.xiaoshangfan.liangshuang.entity.TradeAd;
import cn.xiaoshangfan.liangshuang.entity.User;

public class AdDetail extends Activity {

	Activity mActivity;
	User user = new User();
	TradeAd tradead = new TradeAd();
	boolean areadyGet = false;
	boolean loged = false;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		Bmob.initialize(this, "d9e97f48bdbd826859d9eb6990953e09");
		user = BmobUser.getCurrentUser(this, User.class);

		if (user != null) {
			loged = true;
		}
		mActivity = this;
		setContentView(R.layout.activity_ad_detail);

		Intent intent = this.getIntent();
		Bundle bundle = intent.getExtras();
		final Advertisement ad = (Advertisement) bundle.getSerializable("ad");

		tradead.setUser(user);
		tradead.setAd(ad);
		tradead.setState(0);

		BmobQuery<TradeAd> query = new BmobQuery<TradeAd>();
		query.addWhereEqualTo("ad", ad);
		query.addWhereEqualTo("user", user);
		query.findObjects(this, new FindListener<TradeAd>() {
			@Override
			public void onSuccess(List<TradeAd> object) {
				// TODO Auto-generated method stub
				if (object.size() > 0) {
					areadyGet = true;
				}
			}

			@Override
			public void onError(int code, String msg) {
				// TODO Auto-generated method stub
			}
		});

		ImageView imgAdDetail = (ImageView) findViewById(R.id.imageView_ad_detail);
		Button btn_GetFraction = (Button) findViewById(R.id.button_get_fraction);

		ad.get_ads_img().loadImage(this, imgAdDetail);

		btn_GetFraction.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				final EditText editText = new EditText(mActivity);
				new AlertDialog.Builder(mActivity)
						.setTitle("输入图中文字得积分")
						.setIcon(android.R.drawable.ic_dialog_info)
						.setView(editText)
						.setPositiveButton("确定",
								new DialogInterface.OnClickListener() {

									@Override
									public void onClick(DialogInterface dialog,
											int which) {
										String edTextString = editText
												.getText().toString();

										if (edTextString.length() == 0) {
											Toast.makeText(mActivity, "输入内容为空",
													Toast.LENGTH_LONG).show();
										} else if (edTextString.equals(ad
												.getImg_inside_text())) {

											if (!loged) {
												Toast.makeText(mActivity,
														"登陆后才可以获得积分哦",
														Toast.LENGTH_LONG)
														.show();
											}

											if (areadyGet) {
												Toast.makeText(mActivity,
														"你已经获得过该积分了哦",
														Toast.LENGTH_LONG)
														.show();
											} else {
												tradead.save(mActivity,
														new SaveListener() {

															@Override
															public void onSuccess() {
																// TODO
																// Auto-generated
																// method stub
																Toast.makeText(
																		mActivity,
																		"恭喜你获得该积分",
																		Toast.LENGTH_LONG)
																		.show();

															}

															@Override
															public void onFailure(
																	int arg0,
																	String arg1) {
																// TODO
																// Auto-generated
																// method stub

															}
														});

												int newFraction = user
														.getUserFraction()
														+ ad.get_ads_fraction_get();

												user.setUserFraction(newFraction);
												user.update(mActivity,
														new UpdateListener() {

															@Override
															public void onSuccess() {
																// TODO
																// Auto-generated
																// method stub

															}

															@Override
															public void onFailure(
																	int arg0,
																	String arg1) {
																// TODO
																// Auto-generated
																// method stub
																Toast.makeText(
																		mActivity,
																		"更新用户信息失败",
																		Toast.LENGTH_LONG)
																		.show();

															}
														});

											}

										} else {
											Toast.makeText(mActivity, "输入内容错误",
													Toast.LENGTH_LONG).show();
										}

									}
								})
						.setNegativeButton("取消",
								new DialogInterface.OnClickListener() {
									@Override
									public void onClick(DialogInterface dialog,
											int which) {
										// TODO Auto-generated method stub
									}

								}).show();

			}
		});

	}
}
