package cn.xiaoshangfan.liangshuang.fragments;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

import me.maxwin.view.XListView;
import me.maxwin.view.XListView.IXListViewListener;
import android.annotation.SuppressLint;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.text.format.DateFormat;
import android.text.format.Time;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import cn.bmob.v3.BmobQuery;
import cn.bmob.v3.datatype.BmobDate;
import cn.bmob.v3.listener.FindListener;
import cn.xiaoshangfan.liangshuang.R;
import cn.xiaoshangfan.liangshuang.adapter.AdsAdapter;
import cn.xiaoshangfan.liangshuang.entity.Advertisement;

import com.nostra13.universalimageloader.cache.memory.impl.UsingFreqLimitedMemoryCache;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.nostra13.universalimageloader.core.assist.ImageScaleType;
import com.nostra13.universalimageloader.core.display.FadeInBitmapDisplayer;

public class AdvertisementFragment extends Fragment implements
		IXListViewListener {

	private FragmentActivity activity;
	private XListView waterfall_ads = null;
	private AdsAdapter mAdsAdapter;
	public LinkedList<Advertisement> adsList = new LinkedList<Advertisement>();

	// private long lastRefreshTime;
	Time lastRefreshTime = new Time();

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		View view = inflater.inflate(R.layout.fragment_ads, container, false);

		return view;

	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {

		// 获取当前时间
		// lastRefreshTime = System.currentTimeMillis();
		lastRefreshTime.setToNow();

		// TODO Auto-generated method stub
		super.onActivityCreated(savedInstanceState);
		activity = getActivity();

		// 初始化图片加载库
		DisplayImageOptions options = new DisplayImageOptions.Builder()
				.showImageOnLoading(R.drawable.load_default)
				// 图片存本地
				.cacheInMemory(true).displayer(new FadeInBitmapDisplayer(50))
				.bitmapConfig(Bitmap.Config.RGB_565)
				.imageScaleType(ImageScaleType.EXACTLY) // default
				.build();
		ImageLoaderConfiguration config = new ImageLoaderConfiguration.Builder(
				activity)
				// .memoryCacheExtraOptions(600, 800)
				.memoryCache(new UsingFreqLimitedMemoryCache(16 * 1024 * 1024))
				.defaultDisplayImageOptions(options).build();
		ImageLoader.getInstance().init(config);

		// 设置适配器
		waterfall_ads = (XListView) activity.findViewById(R.id.waterfall_ads);
		waterfall_ads.setXListViewListener(this);
		waterfall_ads.setPullLoadEnable(true);

		// 初始化适配器并且设置到Xlist
		mAdsAdapter = new AdsAdapter(activity, adsList);

		BmobQuery<Advertisement> query = new BmobQuery<Advertisement>();
		query.setLimit(20);// 设置分页，取20个数据
		query.order("-createdAt");
		query.findObjects(activity, new FindListener<Advertisement>() {
			@Override
			public void onSuccess(List<Advertisement> ads) {
				// TODO Auto-generated method stub
				if (ads.size() == 0) {
					Toast.makeText(activity, "没有数据", Toast.LENGTH_LONG).show();
				} else {
					adsList.addAll(ads);
					waterfall_ads.setAdapter(mAdsAdapter);
				}
			}

			@Override
			public void onError(int arg0, String arg1) {
				// TODO Auto-generated method stub
				Toast.makeText(getActivity(), arg1, Toast.LENGTH_LONG).show();
			}

		});
	}

	@SuppressLint("SimpleDateFormat")
	@Override
	public void onRefresh() {

		waterfall_ads.setRefreshTime(lastRefreshTime.hour + ":"
				+ lastRefreshTime.minute + ":" + lastRefreshTime.second);
		lastRefreshTime.setToNow();

		// TODO Auto-generated method stub
		BmobQuery<Advertisement> queryRefresh = new BmobQuery<Advertisement>();
		queryRefresh.setLimit(20);// 设置分页，取20个数据
		queryRefresh.order("createdAt");
		Date date = null;
		try {
			SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			date = df.parse(adsList.get(0).getCreatedAt());
		} catch (Exception ex) {
		}

		// Log.d("send", adsList.get(0).getCreatedAt());

		BmobDate bDate = new BmobDate(date);

		queryRefresh.addWhereGreaterThan("createdAt", bDate);
		queryRefresh.setSkip(1);
		queryRefresh.findObjects(activity, new FindListener<Advertisement>() {
			@Override
			public void onSuccess(List<Advertisement> ads) {
				// TODO Auto-generated method stub
				if (ads.size() == 0) {
					Toast.makeText(activity, "已经是最新了", Toast.LENGTH_LONG)
							.show();
					waterfall_ads.stopRefresh();
				} else {
					for (int i = 0; i < ads.size(); i++) {
						// 添加数据到adsList
						adsList.addFirst(ads.get(i));
						mAdsAdapter.notifyDataSetChanged();
					}
					waterfall_ads.stopRefresh();
				}
			}

			@Override
			public void onError(int arg0, String arg1) {
				// TODO Auto-generated method stub
				Toast.makeText(getActivity(), arg1, Toast.LENGTH_LONG).show();
			}
		});

	}

	@SuppressLint("SimpleDateFormat")
	@Override
	public void onLoadMore() {
		// TODO Auto-generated method stub
		BmobQuery<Advertisement> queryLoadmore = new BmobQuery<Advertisement>();
		queryLoadmore.setLimit(20);// 设置分页，取10个数据
		queryLoadmore.order("-createdAt");

		Date date = null;
		try {
			SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			date = df.parse(adsList.getLast().getCreatedAt());
		} catch (Exception ex) {
		}

		BmobDate bDate = new BmobDate(date);
		queryLoadmore.addWhereLessThan("createdAt", bDate);
		queryLoadmore.setSkip(1);

		queryLoadmore.findObjects(activity, new FindListener<Advertisement>() {
			@Override
			public void onSuccess(List<Advertisement> ads) {
				// TODO Auto-generated method stub
				if (ads.size() == 0) {
					Toast.makeText(activity, "没有更多数据", Toast.LENGTH_LONG)
							.show();
					waterfall_ads.stopLoadMore();
				} else {
					// 添加数据到adsList
					adsList.addAll(ads);
					waterfall_ads.stopLoadMore();
					mAdsAdapter.notifyDataSetChanged();
				}
			}

			@Override
			public void onError(int arg0, String arg1) {
				// TODO Auto-generated method stub
				Toast.makeText(getActivity(), arg1, Toast.LENGTH_LONG).show();
			}
		});
	}

	// private String getTimeString(long lastTime) {
	// // TODO Auto-generated method stub
	// long thisTime = System.currentTimeMillis();
	// int totalsec = (int) ((thisTime - lastTime) / 1000);
	// lastRefreshTime = thisTime;
	//
	// String lastRefreshTime = null;
	//
	// if (totalsec < 3) {
	// lastRefreshTime = "刚刚";
	// return lastRefreshTime;
	// }
	//
	// if (totalsec < 60) {
	// lastRefreshTime = String.valueOf(totalsec) + "秒前";
	// return lastRefreshTime;
	// }
	//
	// int leftmin = totalsec / 60;
	//
	// if (leftmin > 300) {
	// lastRefreshTime = "很久以前";
	// return lastRefreshTime;
	// }
	//
	// int leftsec = totalsec - leftmin * 60;
	//
	// if (leftmin < 60) {
	// lastRefreshTime = leftmin + "分" + leftsec + "秒";
	// } else {
	// int lefthour = leftmin / 60;
	// leftmin = leftmin - lefthour * 60;
	// lastRefreshTime = lefthour + "小时" + leftmin + "分" + leftsec + "秒";
	// }
	// return lastRefreshTime;
	// }
	//
}
