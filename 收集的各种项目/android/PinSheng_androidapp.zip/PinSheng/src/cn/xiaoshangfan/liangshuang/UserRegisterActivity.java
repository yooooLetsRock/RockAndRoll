package cn.xiaoshangfan.liangshuang;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
//import cn.bmob.v3.BmobUser;
import cn.bmob.v3.listener.SaveListener;
import cn.xiaoshangfan.liangshuang.entity.User;

public class UserRegisterActivity extends Activity implements OnClickListener{
	User user = new User();
	EditText password,email;
	Button register;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.user_register);
		// ��ʼ��View
		initView();
		initListener();
	}
	
	private void initView() {
		password = (EditText) findViewById(R.id.editText_Password);
		email = (EditText) findViewById(R.id.editText_Email);
		register = (Button) findViewById(R.id.button_Login);
	}

	private void initListener() {
		register.setOnClickListener(this);
	}
	
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		if (v == register) 
			registerUser();	
	}
	
	public void registerUser(){
		
        final String emailInfo = email.getText().toString();
        String passwordInfo = password.getText().toString();
        user.setUsername(emailInfo);
        user.setPassword(passwordInfo);
        user.setEmail(emailInfo);
        user.signUp(this, new SaveListener() {
        	 
			public void onSuccess() {
        	        // TODO Auto-generated method stub
        	        toast("ע��ɹ�");
        	        Intent intent = new Intent(UserRegisterActivity.this,MainActivity.class);
        	        startActivity(intent);
        	        //Intent data=new Intent();  
    		        //data.putExtra("name", emailInfo); 
    		        //setResult(1, data);  
    		        //finish();
        	    }
        	 public void onFailure(int code, String msg) {
        	        // TODO Auto-generated method stub
        	        toast("ע��ʧ��:"+msg);
        	 }
        });

	}
	
	

	Toast mToast;
	protected void toast(String string) {
		// TODO Auto-generated method stub
		if (!TextUtils.isEmpty(string)) {
			if (mToast == null) {
				mToast = Toast.makeText(getApplicationContext(), string,
						Toast.LENGTH_SHORT);
			} else {
				mToast.setText(string);
			}
			mToast.show();
		}
	}
	

}
