package com.xgr.wonderful.sns;

/**
 * @author kingofglory email: kingofglory@yeah.net blog: http:www.google.com
 * @date 2014-3-3 TODO
 */

public interface TencentShareConstants {

    String TITLE="推荐一个好应用哦~";

    String IMG_URL="http://t2.qpic.cn/mblogpic/357eac0bdbb308df7c30/120";

    String TARGET_URL="http://yuanquan.bmob.cn";

    String SUMMARY="专业小编团队每日推荐平价又时尚的宝贝~宝贝超赞，还包邮哦~";

    String COMMENT="";
}
