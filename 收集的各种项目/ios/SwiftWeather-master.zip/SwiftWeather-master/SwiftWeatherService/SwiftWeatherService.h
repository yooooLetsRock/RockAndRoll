//
//  SwiftWeatherService.h
//  SwiftWeatherService
//
//  Created by Jake Lin on 30/12/2014.
//  Copyright (c) 2014 rushjet. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for SwiftWeatherService.
FOUNDATION_EXPORT double SwiftWeatherServiceVersionNumber;

//! Project version string for SwiftWeatherService.
FOUNDATION_EXPORT const unsigned char SwiftWeatherServiceVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SwiftWeatherService/PublicHeader.h>


